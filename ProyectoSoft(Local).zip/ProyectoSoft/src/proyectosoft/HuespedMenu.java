/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open 
import BD.BD;
import static the template in the editor.
 */
package proyectosoft;

import BD.BD;
import static BD.BD.connect;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;








/**
 *
 * @author Ryes_
 */
public class HuespedMenu extends javax.swing.JFrame {
    
    
void CargarTabla(){ 
    
        //Se crean 2 arrays para guardar datos extraidos de la base de datos
        //En uno de los arrays se declaran los nombres de las columnas MANUALMENTE
        String[] titulos = {"ID", "Nombre","Apellido", "Fecha De Nacimiento ","Tipo De Sangre ", "ID Familiar"};
        String[] registro = new String[6];       
        //Se cargan los títulos de las columnas a la tabla
        DefaultTableModel modelo = new DefaultTableModel  (null, titulos);       
        //Se usa la coneccion para establecer contacto con la base de datos de MySQL
        Connection cn = connect();       
        //Hay que guardar en la variable la instrucción que "pasaremos" a MySQL
        String query = "SELECT * from Huesped";
            
        try 
        {
            //HAy que mandar la instrucción a MySQL con el Statement y el resultado de ese 
            //comando se guarda en un ResulSet
            //(ambos pertenecen a la libreria IMPORT JAVA.SQL )

            Statement st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(query);
            
           //El ResultSet se explora y se extraen los datos para guardarlos
          // en los arrays creados anteriormente
            while (rs.next())
            {
                registro [0] = rs.getString("id_Huesped");
                registro [1] = rs.getString("Nombre");
                registro [2] = rs.getString("Apellido");
                registro [3] = rs.getString("Fecha_De_Nacimiento");
                registro [4] = rs.getString("Tipo_De_Sangre");
                registro [5] = rs.getString("id_Familiar");

                
                
               // {"id_Empleado", "Puestoa","Nombre", "Apellidos","Fecha_De_Nacimiento"};
               // Al "modelo" de la jTable se mandan los datos guardados en los arrays
                modelo.addRow(registro);
            }
            //Una vez se ha terminado el llenado del modelo, este se manda a la jTable
            jTable1.setModel (modelo);
        } 
        catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex);
           
        }
     
    }
    
void CargarTablaFamiliar(){ 
    
        //Se crean 2 arrays para guardar datos extraidos de la base de datos
        //En uno de los arrays se declaran los nombres de las columnas MANUALMENTE
        String[] titulos = {"ID", "Nombre","Apellido", "Telefono ","Email"};
        String[] registro = new String[6];       
        //Se cargan los títulos de las columnas a la tabla
        DefaultTableModel modelo = new DefaultTableModel  (null, titulos);       
        //Se usa la coneccion para establecer contacto con la base de datos de MySQL
        Connection cn = connect();       
        //Hay que guardar en la variable la instrucción que "pasaremos" a MySQL
        String query = "SELECT * from Familiar";
            
        try 
        {
            //HAy que mandar la instrucción a MySQL con el Statement y el resultado de ese 
            //comando se guarda en un ResulSet
            //(ambos pertenecen a la libreria IMPORT JAVA.SQL )

            Statement st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(query);
            
           //El ResultSet se explora y se extraen los datos para guardarlos
          // en los arrays creados anteriormente
            while (rs.next())
            {
                registro [0] = rs.getString("id_Familiar");
                registro [1] = rs.getString("Nombre");
                registro [2] = rs.getString("Apellidos");
                registro [3] = rs.getString("Telefono");
                registro [4] = rs.getString("Email");

                
                
               // {"id_Empleado", "Puestoa","Nombre", "Apellidos","Fecha_De_Nacimiento"};
               // Al "modelo" de la jTable se mandan los datos guardados en los arrays
                modelo.addRow(registro);
            }
            //Una vez se ha terminado el llenado del modelo, este se manda a la jTable
            jTable1.setModel (modelo);
        } 
        catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex);
           
        }
     
    }

    
void CargarTablaBuscar(){ 
   
        String[] titulos = {"ID", "Nombre","Apellido", "Fecha De Nacimiento ","Tipo De Sangre ", "ID Familiar"};
        String[] registro = new String[6];       
        DefaultTableModel modelo = new DefaultTableModel  (null, titulos);       
        Connection cn = connect();       
        int buscador = Integer.parseInt(tbuscar.getText());
        String query = "SELECT * from Huesped where id_Huesped = "+ buscador + " ;";           
        try 
        {          
            Statement st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(query);                     
            while (rs.next())
            {
                registro [0] = rs.getString("id_Huesped");
                registro [1] = rs.getString("Nombre");
                registro [2] = rs.getString("Apellido");
                registro [3] = rs.getString("Fecha_De_Nacimiento");
                registro [4] = rs.getString("Tipo_De_Sangre");
                registro [5] = rs.getString("id_Familiar");
  
                modelo.addRow(registro);
            }
            jTable1.setModel (modelo);
        } 
        catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex);
           
        }
     
    }

void CargarTablaBuscarfm(){ 
    
        //Se crean 2 arrays para guardar datos extraidos de la base de datos
        //En uno de los arrays se declaran los nombres de las columnas MANUALMENTE
        String[] titulos = {"ID", "Nombre","Apellido", "Fecha De Nacimiento ","Tipo De Sangre ", "ID Familiar"};
        String[] registro = new String[6];       
        //Se cargan los títulos de las columnas a la tabla
        DefaultTableModel modelo = new DefaultTableModel  (null, titulos);       
        //Se usa la coneccion para establecer contacto con la base de datos de MySQL
        Connection cn = connect();       
        //Hay que guardar en la variable la instrucción que "pasaremos" a MySQL
        int buscador = Integer.parseInt(tbuscar1.getText());
        String query = "SELECT * from Huesped where id_Familiar = "+ buscador + " ;";
            
        try 
        {
            //HAy que mandar la instrucción a MySQL con el Statement y el resultado de ese 
            //comando se guarda en un ResulSet
            //(ambos pertenecen a la libreria IMPORT JAVA.SQL )

            Statement st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(query);
            
           //El ResultSet se explora y se extraen los datos para guardarlos
          // en los arrays creados anteriormente
            while (rs.next())
            {
                registro [0] = rs.getString("id_Huesped");
                registro [1] = rs.getString("Nombre");
                registro [2] = rs.getString("Apellido");
                registro [3] = rs.getString("Fecha_De_Nacimiento");
                registro [4] = rs.getString("Tipo_De_Sangre");
                registro [5] = rs.getString("id_Familiar");

                
                
               // {"id_Empleado", "Puestoa","Nombre", "Apellidos","Fecha_De_Nacimiento"};
               // Al "modelo" de la jTable se mandan los datos guardados en los arrays
                modelo.addRow(registro);
            }
            //Una vez se ha terminado el llenado del modelo, este se manda a la jTable
            jTable1.setModel (modelo);
        } 
        catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex);
           
        }
     
    }

    public HuespedMenu() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    void CargarTablaBuscarFamiliar(){ 
   
        String[] titulos = {"ID", "Nombre","Apellido", "Telefono ","Email"};
        String[] registro = new String[6];       
        DefaultTableModel modelo = new DefaultTableModel  (null, titulos);       
        Connection cn = connect();       
        int buscador = Integer.parseInt(tbuscar5.getText());
        String query = "SELECT * from Familiar where id_Familiar = "+ buscador + " ;";           
        try 
        {          
            Statement st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(query);                     
            while (rs.next())
            {
                 registro [0] = rs.getString("id_Familiar");
                registro [1] = rs.getString("Nombre");
                registro [2] = rs.getString("Apellidos");
                registro [3] = rs.getString("Telefono");
                registro [4] = rs.getString("Email");
                modelo.addRow(registro);
            }
            jTable1.setModel (modelo);
        } 
        catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex);
           
        }
     
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton5 = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        tbuscar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        registrar = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        tbuscar1 = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        tbuscar5 = new javax.swing.JTextField();
        jButton10 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        jButton5.setText("Eliminar");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel23.setText("Huespéd");

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/huespedes 64.png"))); // NOI18N

        jLabel15.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("Insertar");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(9, 53, 126));

        jButton1.setBackground(new java.awt.Color(9, 21, 83));
        jButton1.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/update 24.png"))); // NOI18N
        jButton1.setText("Actualizar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(9, 21, 83));
        jButton2.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/insert 24.png"))); // NOI18N
        jButton2.setText("Insertar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(9, 21, 83));
        jButton3.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/delete 24.png"))); // NOI18N
        jButton3.setText("Eliminar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellido (s)", "Fecha De Nacimiento", "Tipo Sanguineo", "Id Familiar"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        tbuscar.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        tbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbuscarActionPerformed(evt);
            }
        });
        tbuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tbuscarKeyTyped(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Ingrese ID de huesped");

        jButton4.setBackground(new java.awt.Color(9, 21, 83));
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Menu Principal");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        registrar.setBackground(new java.awt.Color(9, 21, 83));
        registrar.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        registrar.setForeground(new java.awt.Color(255, 255, 255));
        registrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/familiar 32.png"))); // NOI18N
        registrar.setText("Registrar Familiar");
        registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(9, 21, 83));
        jButton6.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/carga (1).png"))); // NOI18N
        jButton6.setText("Cargar Huespedes ");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(9, 21, 83));
        jButton7.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/search.png"))); // NOI18N
        jButton7.setText("Buscar");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/página01.jpg"))); // NOI18N
        jLabel11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel24.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel24.setText("Huespedes");

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/huespedes 64.png"))); // NOI18N

        jLabel16.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("Menú");

        jLabel3.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Ingrese ID de Familiar");

        tbuscar1.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        tbuscar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbuscar1ActionPerformed(evt);
            }
        });
        tbuscar1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tbuscar1KeyTyped(evt);
            }
        });

        jButton8.setBackground(new java.awt.Color(9, 21, 83));
        jButton8.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/search.png"))); // NOI18N
        jButton8.setText("Buscar");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setBackground(new java.awt.Color(9, 21, 83));
        jButton9.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/carga (1).png"))); // NOI18N
        jButton9.setText("Cargar Familiares");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        tbuscar5.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        tbuscar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbuscar5ActionPerformed(evt);
            }
        });
        tbuscar5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tbuscar5KeyTyped(evt);
            }
        });

        jButton10.setBackground(new java.awt.Color(9, 21, 83));
        jButton10.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/search.png"))); // NOI18N
        jButton10.setText("Buscar");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Buscar ID  Familiar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(697, 697, 697)
                        .addComponent(jButton4)
                        .addContainerGap(128, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jButton2)
                                        .addGap(2, 2, 2)
                                        .addComponent(jButton1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 319, Short.MAX_VALUE)
                                        .addComponent(jButton8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addComponent(jLabel4))
                                            .addComponent(tbuscar1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jButton6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jButton9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(registrar)
                                        .addGap(2, 2, 2)
                                        .addComponent(jButton10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(tbuscar5, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jScrollPane1))
                        .addGap(22, 22, 22))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel26)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel24)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 647, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(36, 36, 36))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel3))
                            .addComponent(tbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addGap(11, 11, 11)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel16)
                                .addComponent(jLabel24)))
                        .addGap(27, 27, 27)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton3)
                        .addComponent(jButton2)
                        .addComponent(jButton1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(tbuscar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton8))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(registrar)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jButton9)
                                        .addComponent(jButton6))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(tbuscar5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton10))))))
                .addGap(43, 43, 43)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(90, 90, 90)
                .addComponent(jButton4)
                .addGap(36, 36, 36))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
            HuespedIngresar m = new HuespedIngresar();
            m.setVisible(true);
            this.setVisible(false);
        JOptionPane.showMessageDialog(null,"Para Registrar un Huesped, Debe contar con el ID del Familiar Registrado previamente");

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        HuespedActualizar m = new HuespedActualizar();
            m.setVisible(true);
            this.setVisible(false);
        

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        HuespedEliminar m = new HuespedEliminar();
        m.setVisible(true);
        this.setVisible(false);

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
    MenuPrincipal m = new MenuPrincipal();
        m.setVisible(true);
        this.setVisible(false);    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarActionPerformed
            RegistrodeFamiliar m= new RegistrodeFamiliar();
            m.setVisible (true);
            this.setVisible(false);
    }//GEN-LAST:event_registrarActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
CargarTabla();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
CargarTablaBuscar();
        
        
       
    
        
        
        
        
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
CargarTablaBuscarfm();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
CargarTablaFamiliar();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void tbuscarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbuscarKeyTyped
            char validar = evt.getKeyChar();
            if (Character.isLetter(validar)){
                getToolkit().beep();
                evt.consume();
                
                JOptionPane.showMessageDialog(rootPane, "Ingresar Solo Numeros");
                
            }

    }//GEN-LAST:event_tbuscarKeyTyped

    private void tbuscar1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbuscar1KeyTyped
        char validar = evt.getKeyChar();
            if (Character.isLetter(validar)){
                getToolkit().beep();
                evt.consume();
                
                JOptionPane.showMessageDialog(rootPane, "Ingresar Solo Numeros");
                
            }
    }//GEN-LAST:event_tbuscar1KeyTyped

    private void tbuscar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbuscar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tbuscar1ActionPerformed

    private void tbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tbuscarActionPerformed

    private void tbuscar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbuscar5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tbuscar5ActionPerformed

    private void tbuscar5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbuscar5KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_tbuscar5KeyTyped

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
CargarTablaBuscarFamiliar();
    }//GEN-LAST:event_jButton10ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HuespedMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HuespedMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HuespedMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HuespedMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HuespedMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton registrar;
    private javax.swing.JTextField tbuscar;
    private javax.swing.JTextField tbuscar1;
    private javax.swing.JTextField tbuscar5;
    // End of variables declaration//GEN-END:variables
}
