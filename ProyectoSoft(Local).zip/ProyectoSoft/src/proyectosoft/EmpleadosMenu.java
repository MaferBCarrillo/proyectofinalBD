package proyectosoft;

import BD.BD;
import static BD.BD.connect;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class EmpleadosMenu extends javax.swing.JFrame {
    public EmpleadosMenu() {
        initComponents();
         this.setLocationRelativeTo(null);
    }
    
void CargarTabla(){ 
        //Se crean 2 arrays para guardar datos extraidos de la base de datos
        //En uno de los arrays se declaran los nombres de las columnas MANUALMENTE
        String[] titulos = {"ID", "No.Puesto","Nombre", "Apellidos","Fecha_De_Nacimiento"};
        String[] registro = new String[5];       
        //Se cargan los títulos de las columnas a la tabla
        DefaultTableModel modelo = new DefaultTableModel  (null, titulos);       
        //Se usa la coneccion para establecer contacto con la base de datos de MySQL
        Connection cn = connect();       
        //Hay que guardar en la variable la instrucción que "pasaremos" a MySQL
        String query = "SELECT * from Empleado";
        
        try 
        {
            //HAy que mandar la instrucción a MySQL con el Statement y el resultado de ese 
            //comando se guarda en un ResulSet
            //(ambos pertenecen a la libreria IMPORT JAVA.SQL )

            Statement st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(query);
            
           //El ResultSet se explora y se extraen los datos para guardarlos
          // en los arrays creados anteriormente
            while (rs.next())
            {
                registro [0] = rs.getString("id_Empleado");
                registro [1] = rs.getString("id_Puestoa");
                registro [2] = rs.getString("Nombre");
                registro [3] = rs.getString("Apellidos");
                registro [4] = rs.getString("Fecha_De_Nacimiento");

                
                
               // {"id_Empleado", "Puestoa","Nombre", "Apellidos","Fecha_De_Nacimiento"};
               // Al "modelo" de la jTable se mandan los datos guardados en los arrays
                modelo.addRow(registro);
            }
            //Una vez se ha terminado el llenado del modelo, este se manda a la jTable
            jTable1.setModel (modelo);
        } 
        catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex);
           
        }
     
    }

void CargarTablaMedicos(){ 
        //Se crean 2 arrays para guardar datos extraidos de la base de datos
        //En uno de los arrays se declaran los nombres de las columnas MANUALMENTE
        String[] titulos = {"ID", "Nombre","Apellidos", "Fecha De Nacimiento","Turno","Especialidad"};
        String[] registro = new String[6];       
        //Se cargan los títulos de las columnas a la tabla
        DefaultTableModel modelo = new DefaultTableModel  (null, titulos);       
        //Se usa la coneccion para establecer contacto con la base de datos de MySQL
        Connection cn = connect();       
        //Hay que guardar en la variable la instrucción que "pasaremos" a MySQL
        String query = "SELECT * from Medico";
        
        try 
        {
            //HAy que mandar la instrucción a MySQL con el Statement y el resultado de ese 
            //comando se guarda en un ResulSet
            //(ambos pertenecen a la libreria IMPORT JAVA.SQL )

            Statement st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(query);
            
           //El ResultSet se explora y se extraen los datos para guardarlos
          // en los arrays creados anteriormente
            while (rs.next())
            {
                registro [0] = rs.getString("id_Medico");
                registro [1] = rs.getString("Nombre");
                registro [2] = rs.getString("Apellidos");
                registro [3] = rs.getString("Fecha_De_Nacimiento");
                registro [4] = rs.getString("Turno");
                registro [5] = rs.getString("Especialidad");
                
                
               // {"id_Empleado", "Puestoa","Nombre", "Apellidos","Fecha_De_Nacimiento"};
               // Al "modelo" de la jTable se mandan los datos guardados en los arrays
                modelo.addRow(registro);
            }
            //Una vez se ha terminado el llenado del modelo, este se manda a la jTable
            jTable1.setModel (modelo);
        } 
        catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex);
           
        }
     
    }

void CargarTablaBuscar(){ 
   
        String[] titulos = {"ID", "No.Puesto","Nombre", "Apellidos","Fecha_De_Nacimiento"};
        String[] registro = new String[6];       
        DefaultTableModel modelo = new DefaultTableModel  (null, titulos);       
        Connection cn = connect();       
        int buscador = Integer.parseInt(txtbuscar.getText());
        String query = "SELECT * from Empleado where id_Empleado = "+ buscador + " ;";           
        try 
        {          
            Statement st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(query);                     
            while (rs.next())
            {
                registro [0] = rs.getString("id_Empleado");
                registro [1] = rs.getString("id_Puestoa");
                registro [2] = rs.getString("Nombre");
                registro [3] = rs.getString("Apellidos");
                registro [4] = rs.getString("Fecha_De_Nacimiento");
  
                modelo.addRow(registro);
            }
            jTable1.setModel (modelo);
        } 
        catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex);
           
        }
     
    }



void CargarTablaBuscarMedico(){ 
   
        String[] titulos = {"ID", "Nombre","Apellidos", "Fecha De Nacimiento","Turno","Especialidad"};
        String[] registro = new String[6];       
        DefaultTableModel modelo = new DefaultTableModel  (null, titulos);       
        Connection cn = connect();       
        int buscador = Integer.parseInt(txtbuscar1.getText());
        String query = "SELECT * from Medico where id_Medico = "+ buscador + " ;";           
        try 
        {          
            Statement st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(query);                     
            while (rs.next())
            {
                registro [0] = rs.getString("id_Medico");
                registro [1] = rs.getString("Nombre");
                registro [2] = rs.getString("Apellidos");
                registro [3] = rs.getString("Fecha_De_Nacimiento");
                registro [4] = rs.getString("Turno");
                registro [5] = rs.getString("Especialidad");
  
                modelo.addRow(registro);
            }
            jTable1.setModel (modelo);
        } 
        catch (SQLException ex)
        {
            JOptionPane.showMessageDialog(null, ex);
           
        }
     
    }










    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        txtbuscar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btnc = new javax.swing.JButton();
        btnc1 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnc2 = new javax.swing.JButton();
        txtbuscar1 = new javax.swing.JTextField();
        btnc3 = new javax.swing.JButton();

        jButton2.setText("Insertar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton1.setText("Actualizar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton3.setText("Eliminar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Menu Principal");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Inserte ID Empleado");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(9, 53, 126));

        jTable1.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre(s)", "Apellido(s)", "Fecha De Nacimiento", "Puesto"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton5.setBackground(new java.awt.Color(9, 21, 83));
        jButton5.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/insert 24.png"))); // NOI18N
        jButton5.setText("Insertar");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(9, 21, 83));
        jButton6.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/update 24.png"))); // NOI18N
        jButton6.setText("Actualizar");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(9, 21, 83));
        jButton7.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/delete 24.png"))); // NOI18N
        jButton7.setText("Eliminar");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        txtbuscar.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        txtbuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtbuscarKeyTyped(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Inserte ID Empleado");

        btnc.setBackground(new java.awt.Color(9, 21, 83));
        btnc.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        btnc.setForeground(new java.awt.Color(255, 255, 255));
        btnc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/carga (1).png"))); // NOI18N
        btnc.setText("Cargar Tabla Empleados");
        btnc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncActionPerformed(evt);
            }
        });

        btnc1.setBackground(new java.awt.Color(9, 21, 83));
        btnc1.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        btnc1.setForeground(new java.awt.Color(255, 255, 255));
        btnc1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/search.png"))); // NOI18N
        btnc1.setText("Buscar");
        btnc1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnc1ActionPerformed(evt);
            }
        });

        jButton9.setBackground(new java.awt.Color(9, 21, 83));
        jButton9.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/doctor 32.png"))); // NOI18N
        jButton9.setText("Registrar Medico");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton8.setBackground(new java.awt.Color(9, 21, 83));
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("Menu Principal");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel21.setText("Empleados");

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/employees 64.png"))); // NOI18N

        jLabel7.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Menú");

        jLabel11.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/página01.jpg"))); // NOI18N
        jLabel11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel3.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Inserte ID Medico");

        btnc2.setBackground(new java.awt.Color(9, 21, 83));
        btnc2.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        btnc2.setForeground(new java.awt.Color(255, 255, 255));
        btnc2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/carga (1).png"))); // NOI18N
        btnc2.setText("Cargar Tabla Medicos");
        btnc2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnc2ActionPerformed(evt);
            }
        });

        txtbuscar1.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        txtbuscar1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtbuscar1KeyTyped(evt);
            }
        });

        btnc3.setBackground(new java.awt.Color(9, 21, 83));
        btnc3.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        btnc3.setForeground(new java.awt.Color(255, 255, 255));
        btnc3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/search.png"))); // NOI18N
        btnc3.setText("Buscar");
        btnc3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnc3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton5)
                                .addGap(2, 2, 2)
                                .addComponent(jButton6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel1))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(btnc1)
                                            .addComponent(btnc3))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtbuscar1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel3)))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(btnc)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 203, Short.MAX_VALUE)
                                .addComponent(btnc2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton8)))
                .addGap(61, 61, 61))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(94, 94, 94)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel7)
                                .addComponent(jLabel21))
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton7)
                            .addComponent(jButton5)
                            .addComponent(jButton6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(7, 7, 7)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnc1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addGap(7, 7, 7)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtbuscar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnc3))
                        .addGap(18, 18, 18)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton9)
                    .addComponent(btnc2)
                    .addComponent(btnc))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(81, 81, 81)
                .addComponent(jButton8)
                .addGap(38, 38, 38))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        EmpleadoInsertar m = new EmpleadoInsertar();
        m.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        EmpleadoActualizar m = new EmpleadoActualizar();
        m.setVisible(true);
        this.setVisible(false);

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        EmpleadoEliminar m = new EmpleadoEliminar();
        m.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        MenuPrincipal m = new MenuPrincipal();
        m.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        EmpleadoInsertar m = new EmpleadoInsertar();
        m.setVisible(true);
        this.setVisible(false);
                    JOptionPane.showMessageDialog(null, "Debe contar con el ID del puesto de quien va a registrar, Verifique en Manual de Usuario");

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        EmpleadoActualizar m = new EmpleadoActualizar();
        m.setVisible(true);
        this.setVisible(false);

    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        EmpleadoEliminar m = new EmpleadoEliminar();
        m.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        MenuPrincipal m = new MenuPrincipal();
        m.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void btncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncActionPerformed

CargarTabla();
    }//GEN-LAST:event_btncActionPerformed

    private void btnc1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnc1ActionPerformed
        
      CargarTablaBuscar();
        
    }//GEN-LAST:event_btnc1ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
            RegistrarMedico m = new RegistrarMedico();
            m.setVisible(true);
            this.setVisible(false);

    }//GEN-LAST:event_jButton9ActionPerformed

    private void txtbuscarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtbuscarKeyTyped
                char validar = evt.getKeyChar();
            if (Character.isLetter(validar)){
                getToolkit().beep();
                evt.consume();
                
                JOptionPane.showMessageDialog(rootPane, "Ingresar Solo Numeros");
                
            }    }//GEN-LAST:event_txtbuscarKeyTyped

    private void btnc2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnc2ActionPerformed
        CargarTablaMedicos();
    }//GEN-LAST:event_btnc2ActionPerformed

    private void txtbuscar1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtbuscar1KeyTyped
        char validar = evt.getKeyChar();
            if (Character.isLetter(validar)){
                getToolkit().beep();
                evt.consume();
                
                JOptionPane.showMessageDialog(rootPane, "Ingresar Solo Numeros");
                
            }
    }//GEN-LAST:event_txtbuscar1KeyTyped

    private void btnc3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnc3ActionPerformed
        CargarTablaBuscarMedico();
    }//GEN-LAST:event_btnc3ActionPerformed

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmpleadosMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmpleadosMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmpleadosMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmpleadosMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmpleadosMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnc;
    private javax.swing.JButton btnc1;
    private javax.swing.JButton btnc2;
    private javax.swing.JButton btnc3;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtbuscar;
    private javax.swing.JTextField txtbuscar1;
    // End of variables declaration//GEN-END:variables
}
