
package proyectosoft;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import login.principal;


public class ProyectoSoft {
 
 
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("dsds");
        principal m = new principal();
        m.setVisible(true);
        
    }
    
}

