
package BD;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;


public class BD {
   
    public static Connection connect(){
       String url = "jdbc:mysql://localhost:3306/proyecto";
      //  String url = "jdbc:mysql://sql9.freemysqlhosting.net/sql9267057";
        String user = "root";
        String password = "";
        System.out.println("Conectando...");
           DefaultTableModel modelo;
         String query = "";
        // String url = "jdbc:mysql://localhost:3306/proyecto;";
           
         Connection connection = null;
        try{
           connection = DriverManager.getConnection(url, user,password);
            System.out.println("Conectado!!");

        }catch(SQLException e){
            System.out.println(e.getMessage());
         }
        return connection;
    }
}



/*

public class BD {
   
    public static Connection connect(){
        String url = "jdbc:mysql://localhost:3306/proyecto";
        String user = "root";
        String password = "";
        System.out.println("Conectando...");
           DefaultTableModel modelo;
         String query = "";
         String URL = "jdbc:mysql://localhost:3306/proyecto";
           
         Connection connection = null;
        try{
           connection = DriverManager.getConnection(url, user,password);
            System.out.println("Conectado!!");

        }catch(SQLException e){
            System.out.println(e.getMessage());
         }
        return connection;
    }
}
*/